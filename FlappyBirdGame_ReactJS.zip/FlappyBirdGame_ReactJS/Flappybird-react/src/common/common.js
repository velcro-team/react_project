export var width = window.innerWidth;
export var height = window.innerHeight;

if (width >= 500) { //if this desktop
  width  = 320;
  height = 480;
}
